<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>


<style lang="scss" scoped>
@import "../src/assets/css/main.css";
</style>
