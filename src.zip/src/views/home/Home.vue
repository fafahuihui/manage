<template>
  <div id="home">
    首页
  </div>
</template>

<script>
export default {
  name: 'Home',
  data() {
    return {

    }
  }
}
</script>

<style lang="scss" scoped>

</style>