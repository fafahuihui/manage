<template>
  <div id="otherTwo">
    其他页面二
  </div>
</template>

<script>
export default {
    name: 'OtherTwo',
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>

</style>