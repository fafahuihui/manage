<template>
  <div id="otherOne">
    其他页面一
  </div>
</template>

<script>
export default {
    name: 'OtherOne',
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>

</style>